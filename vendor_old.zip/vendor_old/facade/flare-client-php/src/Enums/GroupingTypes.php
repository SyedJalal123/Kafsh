<?php

namespace Facade\FlareClient\Enums;

/** @deprecated  */
class GroupingTypes
{
    public const TOP_FRAME = 'topFrame';

    public const EXCEPTION = 'exceptionClass';
}
