<?php

namespace Facade\FlareClient\Time;

interface Time
{
    public function getCurrentTime(): int;
}
