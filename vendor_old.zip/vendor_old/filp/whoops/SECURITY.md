# Security Policy

## Supported Versions

Only the latest released version of Whoops is supported.
To facilitate upgrades we almost never make backwards-incompatible changes.

## Reporting a Vulnerability

Please report vulnerabilities over email, by sending an email to `denis` at `sokolov` dot `cc`.


